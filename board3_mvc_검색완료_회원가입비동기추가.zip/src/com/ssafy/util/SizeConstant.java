package com.ssafy.util;

public class SizeConstant {

	public final static int LIST_SIZE = 10;
	public final static int SIZE_PER_LIST = 20;
	
}
